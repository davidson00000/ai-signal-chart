# Sprint 17: Strategy Library v1.0 Management

## 目的
Strategy Library に保存されたストラテジーを効率的に管理・整理・再利用するための包括的なマネジメント機能を追加する。

## 実装内容

### 1. StrategyLibrary クラスの拡張

#### 新規メソッド
- **`update_strategy(strategy_id, updates)`**: 特定フィールドを更新
- **`delete_strategy(strategy_id)`**: 戦略をIDで削除
- **`toggle_favorite(strategy_id)`**: お気に入りフラグを切り替え

#### データ構造の拡張
```json
{
  ...existing fields...,
  "favorite": false  // 既存戦略は false で初期化
}
```

### 2. Strategy Lab - Saved Strategies セクションの強化

#### フィルタ機能
- **Symbol フィルタ**: "All" または保存済み戦略の Symbol から選択
- **Timeframe フィルタ**: "All" / "1d" / "1h" / "5m" から選択
- **⭐ Favorites only**: お気に入りのみ表示するチェックボックス

#### ソート機能
- Return (%) - 収益率順
- Max Drawdown - 最大ドローダウン順
- Created (newest) - 作成日時（新しい順）
- Created (oldest) - 作成日時（古い順）
- Name - 名前順

#### テーブル表示
- **⭐ 列**: お気に入りステータスを表示（⭐ / ☆）
- フィルタ・ソート適用後の件数を表示: "Found X strategies"

#### アクション機能
戦略を選択して以下のアクションを実行可能:

1. **⭐ Toggle Favorite**: お気に入りのオン/オフ切り替え
2. **📂 Load**: Strategy Lab のフォームにパラメータをロード
3. **✏️ Rename**: 
   - クリックでダイアログを表示
   - 新しい名前を入力
   - 💾 Save / ❌ Cancel
4. **🗑️ Delete**:
   - クリックで確認ダイアログを表示
   - ⚠️ 警告メッセージ表示
   - 🗑️ Confirm Delete / ❌ Cancel

### 3. Backtest Lab - ロード中戦略の情報表示

ロード済みの戦略がある場合、以下の情報を expander で表示:

```
📋 Currently Loaded Strategy

Name: Strategy Name
Symbol: AAPL
Timeframe: 1d
Parameters: MA(13, 40)
Return: 1625.54%
Description: (もしあれば)
```

**表示条件**: 
- Symbol, Short Window, Long Window が一致する戦略を自動検出
- 該当戦略がない場合は非表示

## 実行方法

### 1. Strategy Lab での管理
```bash
streamlit run dev_dashboard.py
```

**Strategy Lab タブ** → **Saved Strategies セクション**:
1. フィルタとソートを設定
2. 戦略を選択
3. アクションボタンで操作（Favorite, Load, Rename, Delete）

### 2. Backtest Lab での確認
**Backtest Lab タブ**:
1. "📚 Load from Strategy Library" で戦略をロード
2. "📋 Currently Loaded Strategy" expander で情報確認
3. パラメータが自動セット済みを確認
4. "▶ Run Backtest" で実行

## 技術的詳細

### データ永続化
- **保存先**: `data/strategies.json`
- **フォーマット**: JSON (indent=2 for readability)
- **後方互換性**: 既存戦略に `favorite: false` を自動追加

### Session State 管理
- **Rename dialog**: `rename_strategy_id`, `rename_strategy_name`
- **Delete confirmation**: `delete_strategy_id`, `delete_strategy_name`
- **Loaded strategy**: `strategy_lab_loaded_strategy`

### フィルタ・ソートロジック
1. フィルタを適用（Symbol, Timeframe, Favorite）
2. ソートを適用
3. 結果を表示

## 今後の拡張案
- **タグ機能**: 戦略に複数のタグを付与
- **エクスポート/インポート**: JSON ファイルとして export/import
- **戦略の比較**: 複数戦略を並べて比較表示
- **自動バックアップ**: strategies.json の自動バックアップ
- **検索機能**: 名前や説明文での全文検索
- **パフォーマンス履歴**: 戦略の過去のバックテスト結果を記録
